"use client";

import { useAuth } from "@/contexts/AuthContext";
import Dashboard from "@/components/Dashboard";
import { LogIn, LogOut, MailX } from "lucide-react";

export default function Home() {
  const { user, loading, signInWithGoogle, logOut, disconnectGmail } = useAuth();

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-gray-50">
        <div className="max-w-md w-full p-8 bg-white rounded-lg shadow-md text-center">
          <h1 className="text-3xl font-bold mb-4">Gmail Spend Intelligence</h1>
          <p className="text-gray-600 mb-8">
            Connect your Gmail account to automatically extract structured transaction data from invoices, receipts, and subscriptions.
          </p>
          <button
            onClick={signInWithGoogle}
            className="flex items-center justify-center w-full gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition"
          >
            <LogIn size={20} />
            Sign in with Google
          </button>
          <p className="text-xs text-gray-500 mt-4">
            We only request read-only access to your Gmail to analyze transactional emails. We do not modify or send emails.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <header className="max-w-7xl mx-auto flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Gmail Spend Intelligence</h1>
          <p className="text-sm text-gray-500">Logged in as {user.email}</p>
        </div>
        <div className="flex gap-4">
          <button
            onClick={disconnectGmail}
            className="flex items-center gap-2 px-4 py-2 text-red-600 bg-red-50 hover:bg-red-100 rounded-md transition"
            title="Revoke access and delete all data"
          >
            <MailX size={18} />
            Disconnect Gmail
          </button>
          <button
            onClick={logOut}
            className="flex items-center gap-2 px-4 py-2 text-gray-700 bg-gray-200 hover:bg-gray-300 rounded-md transition"
          >
            <LogOut size={18} />
            Sign Out
          </button>
        </div>
      </header>
      
      <main className="max-w-7xl mx-auto">
        <Dashboard />
      </main>
    </div>
  );
}
