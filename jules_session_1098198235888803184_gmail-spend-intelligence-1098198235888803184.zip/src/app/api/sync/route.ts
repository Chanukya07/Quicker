import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const { uid, googleAccessToken, firebaseToken } = await req.json();

    if (!uid || !googleAccessToken || !firebaseToken) {
      return NextResponse.json({ error: "Missing required parameters." }, { status: 400 });
    }

    const n8nUrl = process.env.NEXT_PUBLIC_N8N_WEBHOOK_URL || "http://localhost:5678/webhook/start-sync";

    const response = await fetch(n8nUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        uid,
        googleAccessToken,
        firebaseToken,
      }),
    });

    if (!response.ok) {
      throw new Error(`n8n responded with status: ${response.status}`);
    }

    const data = await response.json();
    return NextResponse.json(data);
  } catch (error) {
    console.error("Error calling n8n proxy:", error);
    return NextResponse.json({ error: "Failed to trigger sync." }, { status: 500 });
  }
}
