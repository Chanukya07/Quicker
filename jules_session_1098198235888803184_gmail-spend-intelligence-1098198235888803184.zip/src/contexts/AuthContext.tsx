"use client";

import React, { createContext, useContext, useEffect, useState } from "react";
import { User, onAuthStateChanged, signInWithPopup, signOut, GoogleAuthProvider } from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp, deleteDoc, collection, getDocs } from "firebase/firestore";
import { auth, db, googleProvider } from "@/lib/firebase/config";

interface AuthContextType {
  user: User | null;
  loading: boolean;
  googleAccessToken: string | null;
  signInWithGoogle: () => Promise<void>;
  logOut: () => Promise<void>;
  disconnectGmail: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [googleAccessToken, setGoogleAccessToken] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      const token = credential?.accessToken;
      
      if (token) {
        setGoogleAccessToken(token);
        console.log("Google Access Token obtained, length:", token.length);
        
        // Ensure user profile document exists
        const userRef = doc(db, "users", result.user.uid);
        const userDoc = await getDoc(userRef);
        
        if (!userDoc.exists()) {
          await setDoc(userRef, {
            profile: {
              email: result.user.email,
              connectedAt: serverTimestamp(),
              lastSyncAt: null
            }
          });
        }
      }
    } catch (error) {
      console.error("Error signing in with Google", error);
    }
  };

  const logOut = async () => {
    try {
      await signOut(auth);
      setGoogleAccessToken(null);
    } catch (error) {
      console.error("Error signing out", error);
    }
  };

  const disconnectGmail = async () => {
    if (!user) return;
    try {
      // 1. Delete all Firestore data for the user
      // Note: A more robust approach for nested collections is a Cloud Function,
      // but doing basic deletion here for take-home completeness.
      
      const transactionsRef = collection(db, `users/${user.uid}/transactions`);
      const tDocs = await getDocs(transactionsRef);
      tDocs.forEach(async (d) => await deleteDoc(d.ref));
      
      const merchantsRef = collection(db, `users/${user.uid}/merchants`);
      const mDocs = await getDocs(merchantsRef);
      mDocs.forEach(async (d) => await deleteDoc(d.ref));
      
      const flagsRef = collection(db, `users/${user.uid}/insights/flags`);
      const fDocs = await getDocs(flagsRef);
      fDocs.forEach(async (d) => await deleteDoc(d.ref));
      
      // Delete summary
      await deleteDoc(doc(db, `users/${user.uid}/insights/summary`));
      
      // Delete user profile document
      await deleteDoc(doc(db, "users", user.uid));
      
      // 2. Log out
      await logOut();
      
      // In a real app we'd also hit Google OAuth API to revoke the token
    } catch (error) {
      console.error("Error disconnecting Gmail", error);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, googleAccessToken, signInWithGoogle, logOut, disconnectGmail }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
