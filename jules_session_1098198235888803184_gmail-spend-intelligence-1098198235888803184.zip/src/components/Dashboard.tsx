"use client";

import { useAuth } from "@/contexts/AuthContext";
import { useState, useEffect } from "react";
import { RefreshCw, TrendingUp, AlertTriangle, ExternalLink, Calendar, DollarSign, Tag, CreditCard } from "lucide-react";
import { collection, doc, getDoc, getDocs, onSnapshot, query, orderBy, limit } from "firebase/firestore";
import { db } from "@/lib/firebase/config";
import { PieChart as PieChartIcon } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from "recharts";
import { format } from "date-fns";

export default function Dashboard() {
  const { user, googleAccessToken } = useAuth();
  const [syncing, setSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<string | null>(null);

  const [summary, setSummary] = useState<any>(null);
  const [flags, setFlags] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;

    // Listen to summary
    const unsubSummary = onSnapshot(doc(db, `users/${user.uid}/insights/summary`), (doc) => {
      if (doc.exists()) {
        setSummary(doc.data());
      }
    });

    // Listen to flags
    const unsubFlags = onSnapshot(collection(db, `users/${user.uid}/insights/flags`), (snapshot) => {
      const newFlags = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setFlags(newFlags);
    });

    // Listen to transactions (just recent ones for the table)
    const q = query(collection(db, `users/${user.uid}/transactions`), orderBy("date", "desc"), limit(10));
    const unsubTxs = onSnapshot(q, (snapshot) => {
      const newTxs = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setTransactions(newTxs);
    });

    return () => {
      unsubSummary();
      unsubFlags();
      unsubTxs();
    };
  }, [user]);

  const startSync = async () => {
    if (!user || !googleAccessToken) {
      setSyncStatus("Error: Missing user or token.");
      return;
    }

    setSyncing(true);
    setSyncStatus("Syncing...");

    try {
      // Get the Firebase ID token so n8n can authenticate its Firestore calls
      const firebaseToken = await user.getIdToken();

      const response = await fetch("/api/sync", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          uid: user.uid,
          googleAccessToken: googleAccessToken,
          firebaseToken: firebaseToken,
        }),
      });

      if (!response.ok) {
        throw new Error("Sync failed");
      }

      setSyncStatus("Sync triggered successfully.");
      setTimeout(() => setSyncStatus(null), 3000);
    } catch (error) {
      console.error(error);
      setSyncStatus("Error triggering sync.");
    } finally {
      setSyncing(false);
    }
  };

  const getGmailUrl = (messageId: string) => `https://mail.google.com/mail/u/0/#inbox/${messageId}`;

  // Prepare chart data
  const pieData = summary?.byCategory ? Object.keys(summary.byCategory).map(key => ({
    name: key,
    value: summary.byCategory[key]
  })) : [];
  
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#ffc658'];

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-semibold text-gray-900">Data Sync</h2>
          <p className="text-gray-500 text-sm">Pull latest transactions from your Gmail</p>
        </div>
        <div className="flex items-center gap-4">
          {syncStatus && <span className="text-sm text-gray-600">{syncStatus}</span>}
          <button
            onClick={startSync}
            disabled={syncing}
            className={`flex items-center gap-2 px-4 py-2 rounded-md text-white transition ${
              syncing ? "bg-blue-400 cursor-not-allowed" : "bg-blue-600 hover:bg-blue-700"
            }`}
          >
            <RefreshCw size={18} className={syncing ? "animate-spin" : ""} />
            {syncing ? "Syncing..." : "Sync Now"}
          </button>
        </div>
      </div>
      
      {!summary && transactions.length === 0 ? (
        <div className="bg-white p-12 rounded-lg shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center">
          <Calendar size={48} className="text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No transactions found</h3>
          <p className="text-gray-500 max-w-sm">Click "Sync Now" above to scan your Gmail for invoices, receipts, and subscriptions.</p>
        </div>
      ) : (
        <>
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-blue-50 text-blue-600 rounded-md">
                  <DollarSign size={20} />
                </div>
                <h3 className="text-gray-500 font-medium text-sm uppercase tracking-wider">Total Spend</h3>
              </div>
              <p className="text-3xl font-bold text-gray-900">
                ${summary?.totalSpend?.toFixed(2) || '0.00'}
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-purple-50 text-purple-600 rounded-md">
                  <Tag size={20} />
                </div>
                <h3 className="text-gray-500 font-medium text-sm uppercase tracking-wider">Top Category</h3>
              </div>
              <p className="text-xl font-bold text-gray-900 truncate">
                {pieData.length > 0 ? pieData.sort((a, b) => b.value - a.value)[0].name : 'N/A'}
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-green-50 text-green-600 rounded-md">
                  <CreditCard size={20} />
                </div>
                <h3 className="text-gray-500 font-medium text-sm uppercase tracking-wider">Transactions</h3>
              </div>
              <p className="text-3xl font-bold text-gray-900">
                {transactions.length} <span className="text-sm font-normal text-gray-400">recent</span>
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Top Merchants List */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
                <Tag size={20} className="text-gray-500" /> Top Merchants
              </h3>
              <div className="space-y-4">
                {summary?.byMerchant && Object.entries(summary.byMerchant).length > 0 ? (
                  Object.entries(summary.byMerchant)
                    .sort(([, a]: any, [, b]: any) => b - a)
                    .slice(0, 5)
                    .map(([merchant, total]: any) => (
                      <div key={merchant} className="flex justify-between items-center p-3 hover:bg-gray-50 rounded-md transition border border-gray-50">
                        <span className="font-medium text-gray-900">{merchant}</span>
                        <span className="font-bold text-gray-700">${Number(total).toFixed(2)}</span>
                      </div>
                    ))
                ) : (
                  <p className="text-gray-400">No merchants found.</p>
                )}
              </div>
            </div>

            {/* Recurring Payments */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
                <RefreshCw size={20} className="text-purple-500" /> Recurring Payments
              </h3>
              <div className="space-y-4 h-64 overflow-y-auto">
                {summary?.recurringPayments && summary.recurringPayments.length > 0 ? (
                  summary.recurringPayments.map((sub: any, i: number) => (
                    <div key={i} className="flex flex-col p-3 hover:bg-purple-50 rounded-md transition border border-purple-50">
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium text-purple-900">{sub.merchant}</span>
                        <span className="font-bold text-purple-700">${Number(sub.amount).toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-xs text-purple-600">
                        <span>Every ~{sub.intervalDays} days</span>
                        {sub.nextExpected && <span>Next: {format(new Date(sub.nextExpected), 'MMM d')}</span>}
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-gray-400">No recurring payments detected.</p>
                )}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Category Breakdown */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
                <PieChartIcon size={20} className="text-gray-500" /> Spend by Category
              </h3>
              <div className="h-64">
                {pieData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <RechartsTooltip formatter={(value: any) => `$${Number(value).toFixed(2)}`} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-gray-400">No category data</div>
                )}
              </div>
            </div>

            {/* Anomalies */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <h3 className="text-lg font-semibold mb-6 flex items-center gap-2 text-red-600">
                <AlertTriangle size={20} /> Anomalies & Flags
              </h3>
              
              {flags.length > 0 ? (
                <div className="space-y-4">
                  {flags.map((flag) => (
                    <div key={flag.id} className="p-4 bg-red-50 border border-red-100 rounded-md">
                      <div className="flex justify-between items-start mb-2">
                        <span className="font-semibold text-red-800">{flag.merchant}</span>
                        <span className="font-bold text-red-900">${flag.amount.toFixed(2)}</span>
                      </div>
                      <p className="text-sm text-red-700 mb-3">{flag.explanation}</p>
                      <a 
                        href={getGmailUrl(flag.gmailMessageId)} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-xs flex items-center gap-1 text-red-600 hover:text-red-800 font-medium"
                      >
                        View original email <ExternalLink size={12} />
                      </a>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-gray-400">
                  <TrendingUp size={32} className="mb-2 text-green-300" />
                  <p>No anomalies detected</p>
                </div>
              )}
            </div>
          </div>

          {/* Recent Transactions Table */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
            <h3 className="text-lg font-semibold mb-6">Recent Transactions</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="text-xs text-gray-500 uppercase bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 rounded-l-md">Date</th>
                    <th className="px-4 py-3">Merchant</th>
                    <th className="px-4 py-3">Category</th>
                    <th className="px-4 py-3">Amount</th>
                    <th className="px-4 py-3">Type</th>
                    <th className="px-4 py-3 rounded-r-md">Source</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((tx) => (
                    <tr key={tx.id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50 transition">
                      <td className="px-4 py-3 whitespace-nowrap">
                        {tx.date ? format(new Date(tx.date.seconds * 1000), 'MMM d, yyyy') : 'N/A'}
                      </td>
                      <td className="px-4 py-3 font-medium text-gray-900">{tx.merchant}</td>
                      <td className="px-4 py-3">
                        <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs">
                          {tx.category || 'Other'}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-medium text-gray-900">
                        {tx.currency === 'USD' ? '$' : ''}{tx.amount?.toFixed(2)}
                      </td>
                      <td className="px-4 py-3">
                        {tx.is_recurring ? (
                          <span className="flex items-center gap-1 text-purple-600 text-xs font-medium">
                            <RefreshCw size={12} /> Recurring
                          </span>
                        ) : (
                          <span className="text-gray-400 text-xs">One-time</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <a 
                          href={getGmailUrl(tx.gmailMessageId)} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800 flex items-center gap-1"
                          title="View Email"
                        >
                          <ExternalLink size={14} />
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
